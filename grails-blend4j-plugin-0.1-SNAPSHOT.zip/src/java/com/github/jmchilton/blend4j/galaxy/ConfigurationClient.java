package com.github.jmchilton.blend4j.galaxy;

import java.util.Map;

public interface ConfigurationClient {

  Map<String, Object> getRawConfiguration();
  
}

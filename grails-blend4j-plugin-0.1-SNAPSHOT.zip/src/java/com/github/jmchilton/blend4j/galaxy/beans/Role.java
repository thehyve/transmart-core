package com.github.jmchilton.blend4j.galaxy.beans;

public class Role extends GalaxyObject {
  private String name;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}

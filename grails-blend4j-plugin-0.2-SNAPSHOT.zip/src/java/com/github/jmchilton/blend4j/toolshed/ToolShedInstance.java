package com.github.jmchilton.blend4j.toolshed;

public interface ToolShedInstance {

  RepositoriesClient getRepositoriesClient();

  public String getUrl();
  
}

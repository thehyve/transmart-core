package blend4j.plugin

import com.github.jmchilton.blend4j.galaxy.GalaxyInstance
import com.github.jmchilton.blend4j.galaxy.GalaxyInstanceFactory
import com.github.jmchilton.blend4j.galaxy.HistoriesClient
import com.github.jmchilton.blend4j.galaxy.beans.History
import com.github.jmchilton.blend4j.galaxy.beans.HistoryDetails

import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class TesttotoController {

    String url = "http://146.169.35.178:8081";
    String apiKey = "52811dc1a0f0b0527f3ea4e8024800ca";

    def getHistory(){

        GalaxyInstance galaxyInstance = GalaxyInstanceFactory.get(url, apiKey);
        HistoriesClient historiesClient = galaxyInstance.getHistoriesClient();
        String message;
        for(History history : historiesClient.getHistories()) {
            String name = history.getName();
            String id = history.getId();
            message = String.format("Found history with name %s and id %s", name, id);
            System.out.println(message);

            HistoryDetails historyDetails =  historiesClient.showHistory(id);
            message = String.format("the state of the history is %s", historyDetails.getState());
            System.out.println(message);
            String URL = historyDetails.getStateIds().take(1);
            String message2 = String.format("the stateid is : %s", URL);
            System.out.println(message2);

        }

        response.setContentType('APPLICATION/OCTET-STREAM')
        response.setHeader('Content-Disposition', 'Attachment;Filename="example.zip"')

        ZipOutputStream zip = new ZipOutputStream(response.outputStream);
        def file1Entry = new ZipEntry('first_file.txt');
        zip.putNextEntry(file1Entry);
        zip.write(message.bytes);

        zip.close();
        //render WriteToaFile("Hello World");

    }

    def WriteToaFile(String mytext){
        response.setContentType("text/plain")
        response.setHeader("Content-disposition", "attachment; filename=test.txt")
        response << mytext
        return response
    }

}

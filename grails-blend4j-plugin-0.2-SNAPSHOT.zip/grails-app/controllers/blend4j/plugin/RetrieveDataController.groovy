package blend4j.plugin
import com.github.jmchilton.blend4j.galaxy.GalaxyInstance
import com.github.jmchilton.blend4j.galaxy.GalaxyInstanceFactory
import com.github.jmchilton.blend4j.galaxy.LibrariesClient
import com.github.jmchilton.blend4j.galaxy.beans.FileLibraryUpload
import com.github.jmchilton.blend4j.galaxy.beans.Library
import com.github.jmchilton.blend4j.galaxy.beans.LibraryContent
import com.sun.jersey.api.client.ClientResponse
import org.codehaus.groovy.grails.commons.ConfigurationHolder
//import org.transmartproject.db.dataquery.highdim.mrna.DeMrnaAnnotationCoreDb
//import org.transmartproject.db.dataquery.highdim.mrna.DeSubjectMicroarrayDataCoreDb
//import org.transmartproject.db.i2b2data.PatientDimension

class RetrieveDataController {

    def index() { }

    String url = "http://146.169.35.178:8081";
    String apiKey = "52811dc1a0f0b0527f3ea4e8024800ca";

    def seeDataContainedInLibrary(){
        System.out.println("I am in.");
        final GalaxyInstance galaxyInstance = GalaxyInstanceFactory.get(url, apiKey);
        final LibrariesClient librariesClient = galaxyInstance.getLibrariesClient();
        final List<Library> libraries = librariesClient.getLibraries();
        Library testLibrary = null;
        for(final Library library : libraries) {
            System.out.println(library.getName());
            if(library.getName().equals("Example populated library for axeloehmichen@hotmail.fr")) {
                testLibrary = library;
            }
        }
        if(testLibrary == null) {
            System.out.println("the test library is null....");
            return;
        }
        for(final LibraryContent content : librariesClient.getLibraryContents(testLibrary.getId())) {
            final String type = content.getType(); // file or folder
            final String name = content.getName();
            final String id = content.getId();
            final String message = String.format("Found library content of type %s with name %s and id %s", type, name, id);
            System.out.println(message);
        }
    }


    def createDataLibrary(){
        final GalaxyInstance galaxyInstance = GalaxyInstanceFactory.get(url, apiKey);

        final String email = "axeloehmichen@hotmail.fr";

        // Create data library
        final Library library = new Library("library for " + email);
        final LibrariesClient librariesClient = galaxyInstance.getLibrariesClient();
        final Library persistedLibrary = librariesClient.createLibrary(library);

        final File testFile = getTestFileFromDisk();

        // Copy example directory into library
        final FileLibraryUpload upload = new FileLibraryUpload();
        final LibraryContent rootFolder = librariesClient.getRootFolder(persistedLibrary.getId());
        upload.setFolderId(rootFolder.getId());

        upload.setName("guest-DataExport-47");
        upload.setFileType("zip");
        upload.setFile(testFile);
        final ClientResponse uploadResponse = librariesClient.uploadFile(persistedLibrary.getId(), upload);
        assert uploadResponse.getStatus() == 200, String.format("Expected 200 status code, got %d. %s", clientResponse.getStatus(), clientResponse.getEntity(String.class))

//        def microArrayData = DeMrnaAnnotationCoreDb.findById('268');
//        def patient = PatientDimension.findById('155');
//        def assayid = org.transmartproject.db.dataquery.highdim.DeSubjectSampleMapping.findById('21');
//        //def sampleMapping = .findById('GSE4382');
//        String toto = String.format("the MicroArrayData is:%s ; the Patient is :%s  ;  the assay is: %s  ;  the samplemapping is : %s",microArrayData.toString(),patient.toString(),assayid.toString(), "hello" );
//        System.err.println(toto);
//        def row = DeSubjectMicroarrayDataCoreDb.findByProbeAndPatientAndAssayAndTrialName(microArrayData,patient, assayid,'GSE4382');

//        System.err.println(row.getLogIntensity());

//        upload.setContent(row.getRawIntensity().toString());

        //upload.
//        librariesClient.uploadFilesystemPathsRequest(persistedLibrary.getId(), upload);

        // Obtain user object
//        User owner = null;
//        final UsersClient usersClient = galaxyInstance.getUsersClient();
//        for(final User user : usersClient.getUsers()) {
//            if(user.getEmail().equals(email)) {
//                owner = user;
//                break;
//            }
//        }
//        if(owner == null) {
//            // In order to create users like this - use_remote_user must be enabled
//            // in the Galaxy instance's universe_wsgi.ini options.
//            owner = usersClient.createUser(email);
//        }
//
//        // Obtain user role
//        Role ownersPrivateRole = null;
//        final RolesClient rolesClient = galaxyInstance.getRolesClient();
//        for(final Role role : rolesClient.getRoles()) {
//            if(role.getName().equals(email)) {
//                ownersPrivateRole = role;
//                break;
//            }
//        }
//        final String ownersPrivateRoleId = ownersPrivateRole.getId();
//
//        // Set data library permissions
//        final LibraryPermissions permissions = new LibraryPermissions();
//        permissions.getAccessInRoles().add(ownersPrivateRoleId);
//        permissions.getAddInRoles().add(ownersPrivateRoleId);
//        permissions.getManageInRoles().add(ownersPrivateRoleId);
//        permissions.getModifyInRoles().add(ownersPrivateRoleId);
//        librariesClient.setLibraryPermissions(persistedLibrary.getId(), permissions);



    }



    static File getTestFile() {
        try {
            final File tempFile = File.createTempFile("galxtest", ".txt");
            final FileWriter writer = new FileWriter(tempFile);
            try {
                writer.write("Hello World!!!");
            } finally {
                writer.close();
            }
            return tempFile;
        } catch(final IOException ioException) {
            throw new RuntimeException(ioException);
        }
    }

    static File getTestFileFromDisk() {
        try {
            String tempdirectory = ConfigurationHolder.config.com.recomdata.plugins.tempFolderDirectory;
            final File diskFile = new File(tempdirectory+"/guest-DataExport-47.zip" );
            System.err.println(diskFile.absolutePath );
            System.err.println(diskFile.size() );
//            final FileWriter writer = new FileWriter(diskFile);
//            try {
//                writer.write("Hello World!!!");
//            } finally {
//                writer.close();
//            }
            return diskFile;
        } catch(final IOException ioException) {
            throw new RuntimeException(ioException);
        }
    }



}